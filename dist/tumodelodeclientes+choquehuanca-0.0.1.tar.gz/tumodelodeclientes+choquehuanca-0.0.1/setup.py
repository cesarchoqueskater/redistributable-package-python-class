from setuptools import setup, find_packages

setup(
    name='TuModeloDeClientes+Choquehuanca',
    version='0.0.1',
    author='Cesar',
    author_email='cesarchoqueskater@gmail.com',
    description='TuModeloDeClientes',
    packages=find_packages()
)

